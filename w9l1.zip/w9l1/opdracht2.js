function som1(p1, p2){
	return p1 + p2
}

function som2(p1, p2){
	return p1 - p2
}

function som3(p1, p2){
	return p1 * p2
}

function som4(p1, p2){
	return p1 / p2
}

function som5(p1, p2){
	return p1 + p2
}
function som6(p1, p2){
	return p1 - p2
}