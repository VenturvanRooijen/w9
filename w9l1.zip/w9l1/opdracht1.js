function helloWorld(loop){
	var loop
	for(i = 0; i < loop; loop--){
	document.write("Hello World!" + "<br>")}
}